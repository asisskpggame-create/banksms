"""Bank-SMS gateway (v0.20.159, unique amount v0.20.160): the Android «SMS forwarder» app posts every bank SMS to `<panel>/<PANEL_PATH>/sms-in`.

Flow
  1. `receive` parses the text (app/services/sms_parse.py) and stores one `SmsDeposit` per distinct SMS.
  2. `sweep` pairs unused deposits with payments that are WAITING FOR REVIEW (the customer already sent the receipt
     photo) and have exactly the same amount to be paid by transfer. It runs right after every SMS and every 30 s
     from the maintenance loop, so it does not matter whether the SMS or the receipt arrives first.
  3. A pair is approved by itself only when SMS_AUTO_APPROVE is on and the amount is within SMS_AUTO_MAX_TOMAN;
     otherwise the admins get a message «SMS matches order X» and approve with the usual button.

Unique amount (v0.20.160): every IRR payment carries a small tag (`pay_tag_minor`, see pay_tag.py) added to what the
customer transfers, so the SMS amount names ONE payment. With SMS_REQUIRE_RECEIPT=false and SMS_AUTO_APPROVE=true a
tagged payment is approved by the matching SMS alone, even before the receipt photo (`_promote`).

Safety rules (all in code, none depends on the SMS text being honest)
  - the receipt photo is still required: an SMS alone never approves anything;
  - a deposit can only pay an order/top-up that existed when the SMS arrived;
  - if several waiting payments have the same amount and there are fewer deposits, nothing is approved (ambiguous);
  - the deposit is marked used BEFORE the approval, so a crash can only leave the payment for a human;
  - the same SMS (retried by the app) is stored once (unique fingerprint).
"""
import logging
from collections.abc import Callable
from datetime import datetime, timedelta, timezone
from typing import Any

from sqlalchemy import delete, select, update
from sqlalchemy.exc import IntegrityError

from app.models import AuditEvent, Order, Payment, SmsDeposit, TopUp, utcnow
from app.services import access, sms_parse, wallet
from app.services.commerce import get_review_context, review_payment
from app.services.order_code import short_code

logger = logging.getLogger(__name__)

AUTO_NOTE = "sms-auto"  # review_note of a payment approved by an SMS (a marker, not a reason: see web/helpers.py)
KEEP_DAYS = 30          # old SMS rows are deleted after this many days
TEST_MARK = "تست اتصال"  # the app's «test connection» button sends a text with these words


def _utc(dt: datetime | None) -> datetime:
    dt = dt or utcnow()
    return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt.astimezone(timezone.utc)


def _ts(dt: datetime | None) -> float:
    return _utc(dt).timestamp()


def is_test(text: str) -> bool:
    return TEST_MARK in (text or "")


async def receive(session, bank: str, text: str) -> str:
    """Store one SMS. Returns its status: new | ignored | duplicate."""
    parsed = sms_parse.parse(text)
    fp = sms_parse.fingerprint(bank, text)
    if await session.scalar(select(SmsDeposit.id).where(SmsDeposit.fingerprint == fp)) is not None:
        return "duplicate"
    row = SmsDeposit(fingerprint=fp, bank=(bank or "").strip()[:32], amount_minor=parsed.amount_minor,
                     status="new" if parsed.amount_minor else "ignored", reason=parsed.reason,
                     body=sms_parse.normalize(text)[:1000])
    session.add(row)
    try:
        await session.commit()
    except IntegrityError:  # the same SMS arrived twice at the same moment
        await session.rollback()
        return "duplicate"
    return row.status


async def _pending_items(session, settings=None) -> list[sms_parse.Item]:
    """Payments an SMS may pay: receipt already sent (paid by transfer, in rial), the amount being what the customer
    was asked to transfer (price - wallet part + unique tag). With SMS_REQUIRE_RECEIPT off and auto-approve on, also
    payments that carry a unique tag and are still waiting for the receipt photo ("early"), up to the ceiling."""
    early_ok = bool(settings and settings.sms_auto_approve and not getattr(settings, "sms_require_receipt", True))
    limit_minor = max(settings.sms_auto_max_toman, 0) * 10 if settings else 0
    states_o = ("pending_review", "awaiting_payment") if early_ok else ("pending_review",)
    states_t = ("pending_review", "awaiting_receipt") if early_ok else ("pending_review",)
    orders = (await session.scalars(
        select(Order).where(Order.status.in_(states_o), Order.currency == "IRR"))).all()
    held = await wallet.held_map(session, [o.public_id for o in orders])
    items = [sms_parse.Item("order", o.public_id, wallet.payable_minor(o, held.get(o.public_id, 0)), _ts(o.created_at),
                            early=o.status == "awaiting_payment") for o in orders]
    topups = (await session.scalars(
        select(TopUp).where(TopUp.status.in_(states_t), TopUp.currency == "IRR"))).all()
    items += [sms_parse.Item("topup", t.public_id, wallet.payable_minor(t), _ts(t.created_at),
                             early=t.status == "awaiting_receipt") for t in topups]
    tagged = {o.public_id: bool(o.pay_tag_minor) for o in orders} | {t.public_id: bool(t.pay_tag_minor) for t in topups}
    return [i for i in items if i.due_minor > 0
            and (not i.early or (tagged.get(i.public_id) and (limit_minor == 0 or i.due_minor <= limit_minor)))]


async def _promote(session, item: sms_parse.Item) -> bool:
    """An SMS-only approval: move a payment that has no receipt photo yet to «pending review», so the normal approval
    can run. False when it already moved (the customer sent the photo, it expired, an admin closed it)."""
    if item.kind == "order":
        order = await session.scalar(select(Order).where(Order.public_id == item.public_id))
        if order is None:
            return False
        claimed = await session.execute(update(Order).where(Order.id == order.id, Order.status == "awaiting_payment")
                                        .values(status="pending_review").execution_options(synchronize_session=False))
        paid = await session.execute(update(Payment).where(Payment.order_id == order.id, Payment.status == "awaiting_receipt")
                                     .values(status="pending_review").execution_options(synchronize_session=False))
        if claimed.rowcount != 1 or paid.rowcount != 1:
            await session.rollback()
            return False
    else:
        claimed = await session.execute(update(TopUp).where(TopUp.public_id == item.public_id, TopUp.status == "awaiting_receipt")
                                        .values(status="pending_review").execution_options(synchronize_session=False))
        if claimed.rowcount != 1:
            await session.rollback()
            return False
    session.add(AuditEvent(actor_telegram_id=0, action="payment.sms_without_receipt",
                           object_type=item.kind, object_id=item.public_id))
    await session.commit()
    return True


def _toman(minor: int) -> str:
    return f"{minor // 10:,}"


async def _tell_admins(session, bot: Any, admin_ids, text: str) -> None:
    if bot is None:
        return
    try:
        ids = await access.admins_with_permission(session, admin_ids, access.PAYMENTS)
    except Exception:  # noqa: BLE001 - a role lookup problem must not stop the notice
        logger.exception("SMS gateway: could not read admin roles; using all admins")
        ids = list(admin_ids)
    for admin_id in ids:
        try:
            await bot.send_message(admin_id, text)
        except Exception:  # noqa: BLE001 - one unreachable admin must not stop the others
            logger.warning("SMS gateway: could not message admin %s", admin_id)


async def _tell_customer(session, bot: Any, item: sms_parse.Item) -> None:
    """The same message the web panel sends after an approval."""
    if bot is None:
        return
    from app.bot.notifications import customer_decision_text, topup_decision_text  # late: pulls aiogram in
    try:
        if item.kind == "order":
            ctx = await get_review_context(session, item.public_id)
            await bot.send_message(ctx.customer_telegram_id, customer_decision_text(item.public_id, True),
                                   parse_mode="HTML")
        else:
            ctx = await wallet.get_topup_context(session, item.public_id)
            balance = await wallet.get_balance(session, ctx.customer_telegram_id)
            await bot.send_message(ctx.customer_telegram_id,
                                   topup_decision_text(ctx.amount_minor, True, balance), parse_mode="HTML")
    except Exception:  # noqa: BLE001 - the approval is saved; a failed notice must not undo it
        logger.exception("SMS gateway: could not notify the customer of %s", item.public_id)


def _label(item: sms_parse.Item) -> str:
    return f"سفارش {short_code(item.public_id)}" if item.kind == "order" else f"شارژ کیف پول {item.public_id}"


async def sweep(session_factory: Callable[[], Any], bot: Any | None, settings, now: datetime | None = None) -> int:
    """Match unused deposits with waiting payments. Returns the number of payments approved by themselves."""
    if not (settings.sms_gateway_token or "").strip():
        return 0
    now = _utc(now)
    approved = 0
    async with session_factory() as session:
        window = timedelta(hours=max(1, settings.sms_match_window_hours))
        await session.execute(update(SmsDeposit).where(SmsDeposit.status == "new", SmsDeposit.created_at < now - window)
                              .values(status="expired", decided_at=now))
        await session.execute(delete(SmsDeposit).where(SmsDeposit.created_at < now - timedelta(days=KEEP_DAYS)))
        await session.commit()
        rows = (await session.scalars(
            select(SmsDeposit).where(SmsDeposit.status == "new", SmsDeposit.amount_minor.is_not(None))
            .order_by(SmsDeposit.created_at, SmsDeposit.id))).all()
        if not rows:
            return 0
        by_id = {r.id: r for r in rows}
        items = await _pending_items(session, settings)
        if not items:
            return 0
        deposits = [sms_parse.Deposit(r.id, int(r.amount_minor), _ts(r.created_at)) for r in rows]
        pairs, ambiguous = sms_parse.plan_matches(deposits, items)

        for dep in ambiguous:
            row = by_id[dep.id]
            row.status, row.reason, row.decided_at = "ambiguous", "same_amount", now
            await session.commit()
            await _tell_admins(session, bot, settings.admin_ids,
                               f"⚠️ پیامک واریز {_toman(dep.amount_minor)} تومان رسید، ولی چند رسید در انتظار با همین مبلغ "
                               "هست و معلوم نیست کدام پرداخت شده. دستی بررسی و تأیید کنید.")

        limit_minor = max(settings.sms_auto_max_toman, 0) * 10
        for dep, item in pairs:
            row = by_id[dep.id]
            auto = settings.sms_auto_approve and (limit_minor == 0 or item.due_minor <= limit_minor)
            # claim the deposit first: whatever happens next, it can never pay a second payment
            row.status, row.matched_kind, row.matched_id, row.decided_at = (
                "matched" if auto else "manual", item.kind, item.public_id, now)
            await session.commit()
            if not auto:
                why = "" if settings.sms_auto_approve else " (تأیید خودکار خاموش است)"
                await _tell_admins(session, bot, settings.admin_ids,
                                   f"💬 پیامک بانک {_toman(dep.amount_minor)} تومان با {_label(item)} می‌خواند{why}. "
                                   "رسید را بررسی و تأیید کنید.")
                continue
            try:
                if item.early and not await _promote(session, item):
                    raise ValueError("payment is no longer waiting")  # gives the deposit back, like a lost race
                if item.kind == "order":
                    await review_payment(session, item.public_id, 0, True, note=AUTO_NOTE)
                else:
                    await wallet.review_topup(session, item.public_id, 0, True, note=AUTO_NOTE)
            except ValueError:  # decided by someone else a moment ago: give the deposit back
                await session.rollback()
                row = await session.get(SmsDeposit, dep.id)
                if row is not None:
                    row.status, row.matched_kind, row.matched_id, row.decided_at = "new", None, None, None
                    await session.commit()
                continue
            approved += 1
            logger.info("SMS gateway approved %s %s for %s toman", item.kind, item.public_id, _toman(dep.amount_minor))
            await _tell_customer(session, bot, item)
            await _tell_admins(session, bot, settings.admin_ids,
                               f"✅ {_label(item)} با پیامک بانک ({_toman(dep.amount_minor)} تومان) خودکار تأیید شد.")
    return approved

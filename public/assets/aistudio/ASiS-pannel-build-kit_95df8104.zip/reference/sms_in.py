"""`POST /<PANEL_PATH>/sms-in`: the receiving end of the Android «SMS forwarder» app (v0.20.159).

The app sends JSON  {"token": "...", "sms": "<text>", "bank": "<code>"}  and treats every answer that is not 2xx
as a failure (it queues the SMS and retries later). So: a wrong token is 401 (the owner must see it), but an SMS
that is simply not a deposit is answered 200, otherwise the app would resend it forever.

This route is NOT under /api/, so the panel login middleware does not touch it; it has its own token
(SMS_GATEWAY_TOKEN, compared in constant time, wrong guesses counted by the same limiter as the panel login).
It never approves anything by itself: that is `app/services/sms_gateway.py` and its rules.
"""
import logging

from aiohttp import web

from app.config import get_settings
from app.services import sms_gateway
from app.web.security import token_ok
from app.web.server import DEPS, _body, client_ip, json_error

logger = logging.getLogger(__name__)
MIN_TOKEN = 20
MAX_TEXT = 4000


async def sms_in(request: web.Request) -> web.Response:
    deps = request.app[DEPS]
    settings = get_settings()
    expected = (settings.sms_gateway_token or "").strip()
    if len(expected) < MIN_TOKEN:
        return json_error(404, "درگاه پیامک خاموش است (SMS_GATEWAY_TOKEN را تنظیم کنید).")
    client = client_ip(request)
    if deps.limiter.blocked(client):
        return json_error(429, "تلاش‌های ناموفق زیاد بود؛ چند دقیقه بعد دوباره تلاش کنید.")
    data = await _body(request)
    token = data.get("token")
    if not isinstance(token, str) or not token_ok(token.strip(), expected):
        deps.limiter.record_failure(client)
        logger.warning("SMS gateway: wrong token from %s", client)
        return json_error(401, "توکن نامعتبر است.")
    text, bank = data.get("sms"), data.get("bank")
    if not isinstance(text, str) or not text.strip() or len(text) > MAX_TEXT:
        return json_error(400, "متن پیامک نامعتبر است.")
    bank = bank.strip() if isinstance(bank, str) else ""
    if sms_gateway.is_test(text):  # the app's «test connection» button: answer OK, store nothing
        return web.json_response({"ok": True, "status": "test"})
    async with deps.session_factory() as session:
        status = await sms_gateway.receive(session, bank, text)
    approved = 0
    if status == "new":
        try:
            approved = await sms_gateway.sweep(deps.session_factory, deps.bot, settings)
        except Exception:  # noqa: BLE001 - the SMS is stored; the 30 s loop will try again
            logger.exception("SMS gateway: matching failed")
    return web.json_response({"ok": True, "status": status, "approved": approved})


def routes(base: str) -> list:
    return [web.post(base + "/sms-in", sms_in)]

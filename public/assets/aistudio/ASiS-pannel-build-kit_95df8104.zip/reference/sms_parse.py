"""Reads the text of a bank SMS (sent by the Android «SMS forwarder» app) and finds the DEPOSIT amount.

Stdlib only, so it is easy to test. The result is in rial (the bot stores money as rial: toman * 10).

The parser is deliberately strict: when it is not sure that the message is ONE deposit with ONE amount, it
returns `amount_minor=None` and a `reason`; the bot then leaves the payment to a human. A wrong "no" costs an
admin one tap; a wrong "yes" would give a customer a panel without paying.
"""
import hashlib
import re
from dataclasses import dataclass

# Persian and Arabic-Indic digits -> ASCII; Arabic comma / thousands separators -> ",".
_TRANS = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩٬،", "01234567890123456789,,")
_INVISIBLE = dict.fromkeys(map(ord, "\u200c\u200d\u200e\u200f\u202a\u202b\u202c\u202d\u202e\u00a0\ufeff"), " ")

# Things that look like numbers but are not amounts: dates, times, card numbers, masked card/account parts.
_NOISE = (
    re.compile(r"\b\d{2,4}[/\-.]\d{1,2}[/\-.]\d{1,4}\b"),                  # 1405/08/20  20-08-2026
    re.compile(r"\b\d{1,2}:\d{2}(?::\d{2})?\b"),                            # 14:35  14:35:10
    re.compile(r"\b\d{4}[\s\-]?\d{4}[\s\-]?\d{4}[\s\-]?\d{4}\b"),          # 16-digit card
    re.compile(r"\d{4,6}\s?[*xX•#]{2,}\s?\d{2,4}"),                         # 603799******1234
    re.compile(r"[*xX•#]{2,}\s?\d{2,6}"),                                   # ***1234
    re.compile(r"(?:\+98|0098|98)?9\d{9}\b"),                               # mobile number
    re.compile(r"\b0\d{8,}\b"),                                             # account numbers start with 0
)

_NUM = re.compile(r"(?<![\w.])([+\-])?\s?(\d{1,3}(?:,\d{3})+|[1-9]\d{3,11})(?!\d)\s?([+\-])?(?![\w])")

CREDIT_WORDS = ("واریز", "واريز", "دریافت", "ایداع", "إيداع", "افزایش", "بستانکار", "deposit", "credit", "variz")
DEBIT_WORDS = ("برداشت", "پرداخت", "خرید", "کسر", "انتقال از", "بدهکار", "پایا", "ساتنا", "قبض",
               "withdraw", "debit", "purchase")
BALANCE_WORDS = ("مانده", "موجودی", "باقیمانده", "balance", "bal")
FEE_WORDS = ("کارمزد", "wage", "fee")

MAX_TEXT = 2000


@dataclass(frozen=True)
class Parsed:
    amount_minor: int | None  # rial of the deposit; None = not a clear single deposit
    reason: str               # "" when amount_minor is set, else a short English code (kept in the database)


def normalize(text: str) -> str:
    """Latin digits, one space between words: the form that is hashed and parsed."""
    text = (text or "")[:MAX_TEXT].translate(_TRANS).translate(_INVISIBLE)
    return "\n".join(" ".join(line.split()) for line in text.splitlines() if line.strip()).strip()


def fingerprint(bank: str, text: str) -> str:
    """Same SMS (same bank, same normalized text) -> same fingerprint. Used to ignore a retried delivery."""
    raw = f"{(bank or '').strip().lower()}\n{normalize(text)}".lower()
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _blank(match: re.Match) -> str:
    return " " * (match.end() - match.start())  # keep positions, so the context words stay in place


def _has(words: tuple[str, ...], chunk: str) -> bool:
    low = chunk.lower()
    return any(w in low for w in words)


def parse(text: str) -> Parsed:
    text = normalize(text)
    if not text:
        return Parsed(None, "empty")
    cleaned = text
    for pattern in _NOISE:
        cleaned = pattern.sub(_blank, cleaned)

    credit_marked = _has(CREDIT_WORDS, cleaned)
    debit_marked = _has(DEBIT_WORDS, cleaned)

    credits: list[int] = []
    for m in _NUM.finditer(cleaned):
        before = cleaned[max(0, m.start() - 14):m.start()]
        before_tail = before.rstrip(" :：=-")
        sign = m.group(1) or m.group(3) or ""
        if _has(BALANCE_WORDS, before_tail[-12:]) or _has(FEE_WORDS, before_tail[-10:]):
            continue  # «مانده: 5,000,000» and «کارمزد 1,200» are not the payment
        value = int(m.group(2).replace(",", ""))
        if sign == "-":
            return Parsed(None, "debit")
        if sign == "+" or (credit_marked and not debit_marked):
            credits.append(value)
        elif debit_marked and not credit_marked:
            return Parsed(None, "debit")
        elif credit_marked and debit_marked:
            return Parsed(None, "mixed_direction")
    if not credits:
        return Parsed(None, "no_credit_amount" if not debit_marked else "debit")
    if len(set(credits)) > 1:
        return Parsed(None, "several_amounts")
    amount = credits[0]
    if "تومان" in text and "ریال" not in text and "ريال" not in text:
        amount *= 10
    return Parsed(amount, "")


# ------------------------------------------------------------------ matching (pure, no database)
@dataclass(frozen=True)
class Deposit:
    id: int
    amount_minor: int
    at: float = 0.0   # when the SMS reached the bot (any orderable value, e.g. a timestamp)


@dataclass(frozen=True)
class Item:
    kind: str         # "order" | "topup"
    public_id: str
    due_minor: int    # what must arrive by transfer: price minus the wallet part, plus the unique tag
    at: float = 0.0   # when the order / top-up was made
    early: bool = False  # the receipt photo has not been sent yet (only matched when SMS_REQUIRE_RECEIPT is off)


def plan_matches(deposits: list[Deposit], items: list[Item]) -> tuple[list[tuple[Deposit, Item]], list[Deposit]]:
    """Pair unused deposits with pending payments of exactly the same amount.

    A deposit can only pay something that existed when it arrived (item.at <= deposit.at): an old deposit cannot
    pay an order made later. For one amount X, with D such deposits and I such pending payments:
      I <= D  -> every pending payment is paid (any pairing is the same money): approve them all;
      I >  D  -> nobody can tell WHICH of the I customers paid: nothing is approved, those deposits are ambiguous.
    `deposits` must be oldest first. Returns (pairs to approve, ambiguous deposits)."""
    pairs: list[tuple[Deposit, Item]] = []
    ambiguous: list[Deposit] = []
    for amount in sorted({d.amount_minor for d in deposits}):
        ds = [d for d in deposits if d.amount_minor == amount]
        its = [i for i in items if i.due_minor == amount]
        its = [i for i in its if any(d.at >= i.at for d in ds)]          # something paid after it existed
        ds = [d for d in ds if any(d.at >= i.at for i in its)]           # and it can pay something
        if not its:
            continue
        its.sort(key=lambda i: i.at)
        if len(its) <= len(ds):
            pairs.extend(zip(ds, its))
        else:
            ambiguous.extend(ds)
    return pairs, ambiguous
